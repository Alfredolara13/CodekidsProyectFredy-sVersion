/* Archivo archivado: dev-auth-mock.js
   Este archivo era un mock local usado únicamente en desarrollo.
   Se ha movido a: dev_artifacts_removed/dev-auth-mock.js.copy
   NO debe usarse en producción. Si necesitas restaurarlo, copia desde el archivo archivado.
*/
console.warn('Archivo dev-auth-mock.js neutralizado (archivado).');
