import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";

// Configuración de Firebase
const firebaseConfig = {
  apiKey: "AIzaSyBLttriXlGnoaBASo3jLAHzrf0uU91_pnI",
  authDomain: "codekidsv1.firebaseapp.com",
  projectId: "codekidsv1",
  storageBucket: "codekidsv1.firebasestorage.app",
  messagingSenderId: "378178260762",
  appId: "1:378178260762:web:4bda5188e644713577a6a3",
  measurementId: "G-QRDC49P19X"
};

// Inicializar Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);

export { app, analytics };