"""
Script archivado: check_login_resources.py

Este script se usó temporalmente para comprobar recursos durante pruebas locales.
Se movió a: dev_artifacts_removed/check_login_resources.py.copy

No debe ejecutarse en el repositorio principal.
"""
print('check_login_resources.py neutralizado — copia archivada en dev_artifacts_removed')
